# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 11:34:11 2024

@author: HP
"""


import sqlite3

class Database:
    def __init__(self, db_name='finance.db'):
        self.conn = sqlite3.connect(db_name)
        self.create_tables()

    def create_tables(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY,
                    date TEXT,
                    description TEXT,
                    amount REAL,
                    category TEXT,
                    account TEXT
                )
            ''')

    def add_transaction(self, date, description, amount, category, account):
        with self.conn:
            self.conn.execute('''
                INSERT INTO transactions (date, description, amount, category, account)
                VALUES (?, ?, ?, ?, ?)
            ''', (date, description, amount, category, account))

    def fetch_transactions(self):
        with self.conn:
            return self.conn.execute('SELECT * FROM transactions').fetchall()

    def delete_transaction(self, transaction_id):
        with self.conn:
            self.conn.execute('DELETE FROM transactions WHERE id = ?', (transaction_id,))

