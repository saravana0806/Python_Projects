# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 08:28:07 2024

@author: HP
"""

from ui import FinanceTrackerApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = FinanceTrackerApp(root)
    root.mainloop()
