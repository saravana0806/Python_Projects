# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 08:27:16 2024

@author: HP
"""

import tkinter as tk
from tkinter import ttk
from database import Database
from data_processing import get_monthly_summary
from visualization import plot_monthly_summary

class FinanceTrackerApp:
    def __init__(self, root):
        self.db = Database()
        self.root = root
        self.root.title('Personal Finance Tracker')

        self.create_widgets()

    def create_widgets(self):
        # Entry fields for transaction input
        self.date_entry = ttk.Entry(self.root)
        self.date_entry.grid(row=0, column=1)

        self.desc_entry = ttk.Entry(self.root)
        self.desc_entry.grid(row=1, column=1)

        self.amount_entry = ttk.Entry(self.root)
        self.amount_entry.grid(row=2, column=1)

        self.cat_entry = ttk.Entry(self.root)
        self.cat_entry.grid(row=3, column=1)

        self.acc_entry = ttk.Entry(self.root)
        self.acc_entry.grid(row=4, column=1)

        # Labels
        ttk.Label(self.root, text="Date (YYYY-MM-DD):").grid(row=0, column=0)
        ttk.Label(self.root, text="Description:").grid(row=1, column=0)
        ttk.Label(self.root, text="Amount:").grid(row=2, column=0)
        ttk.Label(self.root, text="Category:").grid(row=3, column=0)
        ttk.Label(self.root, text="Account:").grid(row=4, column=0)

        # Buttons
        ttk.Button(self.root, text="Add Transaction", command=self.add_transaction).grid(row=5, column=0, columnspan=2)
        ttk.Button(self.root, text="Show Summary", command=self.show_summary).grid(row=6, column=0, columnspan=2)

    def add_transaction(self):
        date = self.date_entry.get()
        description = self.desc_entry.get()
        amount = float(self.amount_entry.get())
        category = self.cat_entry.get()
        account = self.acc_entry.get()

        self.db.add_transaction(date, description, amount, category, account)

    def show_summary(self):
        # Example: Show summary for June 2024
        summary = get_monthly_summary(6, 2024)
        plot_monthly_summary(summary)

if __name__ == "__main__":
    root = tk.Tk()
    app = FinanceTrackerApp(root)
    root.mainloop()
