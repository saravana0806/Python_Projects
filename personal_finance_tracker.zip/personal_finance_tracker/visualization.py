# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 08:26:24 2024

@author: HP
"""

import matplotlib.pyplot as plt

def plot_monthly_summary(summary):
    categories = list(summary.keys())
    amounts = list(summary.values())

    plt.figure(figsize=(10, 5))
    plt.bar(categories, amounts, color='skyblue')
    plt.xlabel('Category')
    plt.ylabel('Amount')
    plt.title('Monthly Summary')
    plt.show()
