# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 08:25:53 2024

@author: HP
"""

from database.py import Database

def get_monthly_summary(month, year):
    db = Database()
    transactions = db.fetch_transactions()
    summary = {}
    for transaction in transactions:
        date, amount = transaction[1], transaction[3]
        if date.startswith(f'{year}-{month:02d}'):
            category = transaction[4]
            if category not in summary:
                summary[category] = 0
            summary[category] += amount
    return summary
